Bluetooth_Low_Energy
====================

Bluetooth 4.0 Low Energy (BLE)

The Bluetooth Board is a breakout board for HM-10 BLE module powered by a TI CC2540. 
It is full programmable with CC-Debugger or SmartRF04EB.

Info about the BLE module can be found here: http://www.jnhuamao.cn/

HM-10 Datasheet can be downloaded from here:  http://www.jnhuamao.cn/bluetooth40_en.rar


Info about the famous CC2540 can be found on TI website http://www.ti.com/product/cc2540&DCMP=LowPowerRFICs+Other&HQS=Other+OT+cc2540
