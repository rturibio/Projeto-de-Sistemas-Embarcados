Maker-Tools-Eagle-Libraries
===================

Maker-Tools' Public Eagle PCB Footprints using Eagle 6.0+ 

By downloading these files, you acknowledge that you are using the files at your own risk. We cannot be held responsible for faulty PCBs. Always check your parts against a 1:1 printout.

Licensing CC v3.0 Share-Alike (http://creativecommons.org/licenses/by-sa/3.0/) You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder.

Installing Eagle: https://learn.sparkfun.com/tutorials/how-to-install-and-setup-eagle

Creating Schematics: https://learn.sparkfun.com/tutorials/using-eagle-schematic

Creating Boards: https://learn.sparkfun.com/tutorials/using-eagle-board-layout
