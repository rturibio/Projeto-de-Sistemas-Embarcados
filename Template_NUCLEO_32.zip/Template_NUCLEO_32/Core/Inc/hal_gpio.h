/*
  Configura��o dos pinos de GPIO.
*/


#ifndef _HAL_GPIO_HEADER_SENTRY_
#define _HAL_GPIO_HEADER_SENTRY_

#include "main.h"

// Prototipe das fun��es exportadas.

void hal_gpio_init(void);
void MX_GPIO_Init(void);

#endif

